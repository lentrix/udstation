<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="keywords" values="Mater Dei College, Tubigon, Bohol, Junior High School, Senior High School, Elementary, Kindergarten, College, Higher Education, MDC ">
    <title>Mater Dei College - Official Web Site</title>
    <?php wp_head();?>
</head>
<body <?php body_class(); ?>>
    <div class="container page-container">
        <header>
            <?php get_search_form(); ?>    

            <a href="<?= home_url();?>">
                <img src="<?= get_template_directory_uri() . '/images/MDC-Logo-clipped.png' ?>" alt="MDC Logo">
                <span class="title">Mater Dei College</span><br>
                <span class="subtitle">
                    Tubigon, Bohol, Philippines<br>
                    Tel. No. +63 38 508 8106
                </span>
            </a>
        </header>
        
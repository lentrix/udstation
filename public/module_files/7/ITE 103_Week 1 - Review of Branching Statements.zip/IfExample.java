//Java Program to demonstate the use of if statement.  
public class IfExample {  
    public static void main(String[] args) {  
        //defining an 'age' variable  
        int age=20;  
        //checking the age  
        if(age>18){  
            System.out.print("Age is greater than 18");  
        }  
    }  
} 
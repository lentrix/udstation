<?php
/*
Template Name: Search Page
*/
?>

<?php get_header(); ?>

<div class="strip"></div>

<div class="row">
    <div class="col-lg-3 sidebar">
        <!-- nav -->
        <?php include('nav.php'); ?>
    </div>
    <div class="col-lg-9 main-content">
        <h2>Search Results</h2>
        <p>Search key: '<?= $_GET['s'] ?>'</p>

        <section id="primary" class="content-area">
            <div id="content" class="site-content" role="main">

            <?php if ( have_posts() ) : ?>

                <?php /* Start the Loop */ ?>
                <?php while ( have_posts() ) : the_post(); ?>

                    <div class="row">
                        <div class="col" style="border-bottom: 1px solid #dfdfdf; background-color: #fff; margin-bottom: 10px;">
                            <h2><a href="<?= the_permalink() ?>"><?= the_title(); ?></a></h2>
                            <p><?= the_excerpt(); ?></p>
                        </div>
                    </div>

                <?php endwhile; ?>

            <?php else : ?>

                <p>No results found.</p>
                
            <?php endif; ?>

            </div><!-- #content .site-content -->
        </section><!-- #primary .content-area -->



    </div>
</div>

<?php get_footer(); ?>
<!-- <div class="list-group list-group-flush main-nav">
    <a href="#" class="list-group-item list-group-item-action">Home</a>
    <a href="#" class="list-group-item list-group-item-action">About Us</a>
    <a href="#" class="list-group-item list-group-item-action">Admission</a>
    <a href="#" class="list-group-item list-group-item-action">Scholarship</a>
    <a href="#" class="list-group-item list-group-item-action">Program Offerings</a>
    <a href="#" class="list-group-item list-group-item-action">PGTA</a>
</div> -->

<!-- <div class="sidebar">
    <div>
        

        
    </div>
</div> -->

<div class="sidebar">
    <div class="sidebar-container">
        <?php 
            wp_nav_menu([
                'menu' => 'Primary',
                'container_class' => 'menu'
            ]);
        ?>
        <br>
        <div class="calendar-widget">
            <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar("Sidebar Widget 1") ) : ?>
            <?php endif;?>
        </div>
    </div>
</div>
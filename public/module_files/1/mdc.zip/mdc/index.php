<?php get_header(); ?>

What?


<?php get_footer(); ?>
<?php get_header();?>

<div class="featured" style="margin-bottom: 0!important;">
    <div class="tagline" style="margin-left: 100px; margin-top: 50px; color: #dfdfdf">
        <h1>Mater Dei College Advocates:</h1>
        <p>Wisdom thru Scholarship, Charity thru Service, Prayerlife thru Living the Gospel.</p>
    </div>
</div>

<div class="row">
    <div class="col-lg-3">
        <!-- nav -->
        <?php include('nav.php'); ?>
    </div>
    <div class="col-lg-9 main-content">
            <!-- content -->
            <div class="row">
                <div class="col-lg-6">
                    <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar("Announcement Area") ) : ?>
                    <?php endif;?>
                </div>
                <div class="col-lg-6">
                    <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar("UpComing Area") ) : ?>
                    <?php endif;?>
                </div>
            </div>
            
            <div class="row col" style="margin-top: 20px">
                <h2>MDC Updates</h2>
            </div>
            <div class="row">
            <?php 
                // the query
                $the_query = new WP_Query( array(
                    'posts_per_page' => 3,
                )); 
                ?>

                <?php if ( $the_query->have_posts() ) : ?>
                <?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
                    <div class="col-lg-4">
                        <img src="<?php echo wp_get_attachment_url( get_post_thumbnail_id() ) ?>" style="width: 100%; height: auto" alt="">
                        <a href="<?= the_permalink() ?>"><div class="blog-title"><?php the_title(); ?></div></a>
                        <p class="blog-details">
                            by <?= get_the_author(); ?>
                        </p>
                        <?php the_excerpt(); ?>
                    </div>
                <?php endwhile; ?>
                <?php wp_reset_postdata(); ?>

                <?php else : ?>
                <p><?php __('No News'); ?></p>
                <?php endif; ?>
            </div>

            <div class="row ads">
                <div class="col">
                    <a href="https://mikrotik.com/training/academy" target="_blank">
                        <img src="<?= get_template_directory_uri() . '/images/mikrotik_academy.png'?>" alt="mikrotik academy" width="300">
                    </a>
                </div>
            </div>
    </div>
</div>

<?php get_footer();?>
<?php

function load_styles() {

    wp_register_style('bootstrap', get_template_directory_uri() . '/`css/bootstrap.min.css',[],false,'all');
    wp_enqueue_style('bootstrap');
    
    wp_register_style('style', get_template_directory_uri() . '/`css/style.css',[],false,'all');
    wp_enqueue_style('style');

}
add_action('wp_enqueue_scripts','load_styles');


function register_my_menu() {
    register_nav_menu('primary-menu',__( 'Primary Menu' ));
}
add_action( 'init', 'register_my_menu' );


function mytheme_post_thumbnails() {
    add_theme_support( 'post-thumbnails' );
    add_image_size('post-thumb',300,250);
}
add_action( 'after_setup_theme', 'mytheme_post_thumbnails' );

register_sidebar( [
    'name' => __( 'Announcement Area' ),
    'id' => 'widget-announcement',
    'description' => __( 'Widget for Announcements'),
    'before_widget' => "<div class='card'>",
    'after_widget' => "</div></div>",
    'before_title' => '<div class="card-header"><h3>',
    'after_title' => '</h3></div><div class="card-body widget-card-body">',
]);

register_sidebar( [
    'name' => __( 'UpComing Area' ),
    'id' => 'widget-upcoming',
    'description' => __( 'Widget for Announcements'),
    'before_widget' => "<div class='card'>",
    'after_widget' => "</div></div>",
    'before_title' => '<div class="card-header"><h3>',
    'after_title' => '</h3></div><div class="card-body widget-card-body">',
]);

register_sidebar( [
    'name' => __( 'Sidebar Widget 1' ),
    'id' => 'widget-sidebar1',
    'description' => __( 'Widget for Announcements'),
    'before_widget' => "<div class='widget-sidebar1'>",
    'after_widget' => "</div>",
    'before_title' => '<h3>',
    'after_title' => '</h3>',
]);




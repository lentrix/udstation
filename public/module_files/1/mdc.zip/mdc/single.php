<?php get_header();?>

<div class="strip"></div>

<div class="row">
    <div class="col-lg-3 sidebar">
        <!-- nav -->
        <?php include('nav.php'); ?>
    </div>
    <div class="col-lg-9 main-content">
        <?php if(have_posts()): while(have_posts()): the_post(); ?>
        
        <img src="<?= wp_get_attachment_url( get_post_thumbnail_id($post->ID) ) ?>" style="width: 100%;" alt="">

        <h2 style="margin-top: 20px; margin-bottom:5px;"><?php the_title(); ?></h2>
        <p class="blog-details">by <?php the_author();?> on <?php the_date();?></p>

        <?php the_content(); ?>
    <?php endwhile; endif; ?>
    </div>
</div>
<?php get_footer();?>
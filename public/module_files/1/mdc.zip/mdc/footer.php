    <footer>
        Copyright &copy; 2019. Mater Dei College<br>
        All rights reserved.
    </footer>
<?php wp_footer();?>

</body>
</html>